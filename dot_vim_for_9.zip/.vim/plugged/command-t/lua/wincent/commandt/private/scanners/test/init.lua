-- SPDX-FileCopyrightText: Copyright 2022-present Greg Hurrell and contributors.
-- SPDX-License-Identifier: BSD-2-Clause

describe('blinking light demo', function()
  it('blinks', function()
    expect(1).to_equal(1)
  end)
end)
