-- SPDX-FileCopyrightText: Copyright 2022-present Greg Hurrell and contributors.
-- SPDX-License-Identifier: BSD-2-Clause

return {
  major = 6,
  minor = 0,
  patch = 0,
  prerelease = 'b.1',
  version = '6.0.0-b.1',
}
